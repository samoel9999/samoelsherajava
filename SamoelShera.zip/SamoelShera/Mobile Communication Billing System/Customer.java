package bill;

public class Customer {
    private String name;
    private int callMinutes;
    private int smsCount;
    private int internetMB;
    private double preTaxAmount;
    private double tax;
    private double withTaxAmount;

    public Customer(String name, int callMinutes, int smsCount, int internetMB) {
        this.name = name;
        this.callMinutes = callMinutes;
        this.smsCount = smsCount;
        this.internetMB = internetMB;
    }
}
