package bill;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BillMain {

    public static void main(String[] args) {
        if (args.length != 2) {
            System.err.println("Usage: java bill.BillMain input_file output_file");
            System.exit(1);
        }

        String inputFile = args[0];
        String outputFile = args[1];

        List<Customer> customers = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                String name = parts[0];
                int callMinutes = Integer.parseInt(parts[1]);
                int smsCount = Integer.parseInt(parts[2]);
                int internetMB = Integer.parseInt(parts[3]);

                Customer customer = new Customer(name, callMinutes, smsCount, internetMB);
                customers.add(customer);
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
            System.exit(1);
        }

        for (Customer customer : customers) {
            calculateBill(customer);
        }

        Collections.sort(customers, (c1, c2) -> Double.compare(c1.getWithTaxAmount(), c2.getWithTaxAmount()));

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {
            for (Customer customer : customers) {
                writer.write(customer.getName() + "," + customer.getPreTaxAmount() + "," +
                        customer.getTax() + "," + customer.getWithTaxAmount());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error writing file: " + e.getMessage());
            System.exit(1);
        }
    }

    private static void calculateBill(Customer customer) {
        
    }
}
