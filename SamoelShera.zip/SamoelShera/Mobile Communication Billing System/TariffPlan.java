package bill;

public class TariffPlan {
    private char planCode;
    private String planName;
    private double callRate;
    private double smsRate;
    private double internetRate;
    private double monthlyFee;
    private int includedMinutes;
    private int includedSMS;
    private int includedInternetMB;
}
