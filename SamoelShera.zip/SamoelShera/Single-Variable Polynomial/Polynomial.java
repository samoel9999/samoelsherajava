import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

class Polynomial {
    private List<PolynomialTerm> terms;

    public Polynomial() {
        this.terms = new ArrayList<>();
    }

    public List<PolynomialTerm> getTerms() {
        return terms;
    }

    public void addTerm(PolynomialTerm term) {
        terms.add(term);
    }

    public Polynomial derive() {
        Polynomial derivative = new Polynomial();
        for (PolynomialTerm term : terms) {
            PolynomialTerm derivedTerm = term.derive();
            if (derivedTerm != null) {
                derivative.addTerm(derivedTerm);
            } else {
                return null;
            }
        }
        return derivative;
    }
}

class PolynomialProcessor {
    private String inputFile;
    private String outputFile;

    public PolynomialProcessor(String inputFile, String outputFile) {
        this.inputFile = inputFile;
        this.outputFile = outputFile;
    }

    public void process() throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {

            String line;
            while ((line = reader.readLine()) != null) {
                String result = processPolynomial(line);
                writer.write(result);
                writer.newLine();
            }
        }
    }

    private String processPolynomial(String line) {
        return "";
    }
}

