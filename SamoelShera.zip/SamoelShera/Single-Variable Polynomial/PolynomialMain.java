import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class PolynomialMain {

    public static void main(String[] args) {
        if (args.length != 2) {
            System.err.println("Usage: java PolynomialMain input_file output_file");
            System.exit(1);
        }

        String inputFile = args[0];
        String outputFile = args[1];

        try {
            PolynomialProcessor processor = new PolynomialProcessor(inputFile, outputFile);
            processor.process();
        } catch (IOException e) {
            System.err.println("Error reading or writing file: " + e.getMessage());
        }
    }
}
