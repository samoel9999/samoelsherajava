import java.util.ArrayList;
import java.util.List;

class PolynomialTerm {
    private double coefficient;
    private char variable;
    private int exponent;

    public PolynomialTerm(double coefficient, char variable, int exponent) {
        this.coefficient = coefficient;
        this.variable = variable;
        this.exponent = exponent;
    }

    public double getCoefficient() {
        return coefficient;
    }

    public char getVariable() {
        return variable;
    }

    public int getExponent() {
        return exponent;
    }

    public PolynomialTerm derive() {
        if (exponent == 0) {
            return null;
        }
        return new PolynomialTerm(coefficient * exponent, variable, exponent - 1);
    }
}
